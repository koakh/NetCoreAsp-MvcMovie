﻿using Microsoft.AspNetCore.Mvc;
using System.Text.Encodings.Web;

namespace MvcMovie.Controllers
{
    public class HelloWorldController : Controller
    {
        // GET: /HelloWorld/
        //The Index method above uses a view template to generate an HTML response to the browser.Controller methods (also known as action methods) 
        //such as the Index method above, generally return an IActionResult(or a class derived from ActionResult), not primitive types like string.
        public IActionResult Index()
        {
            //Because you didn’t explicitly specify the name of the view template file to use, 
            //MVC defaulted to using the Index.cshtml view file in the / Views / HelloWorld folder
            return View();
        }

        // GET: /HelloWorld/Welcome/3?name=Rick
        public IActionResult Welcome(string name, int numTimes = 1)
        {
            //The code above uses HtmlEncoder.Default.Encode to protect the app from malicious input (namely JavaScript). 
            //It also uses Interpolated Strings.
            //return HtmlEncoder.Default.Encode($"Hello {name}, ID: {ID}");

            ViewData["Message"] = "Hello " + name;
            ViewData["NumTimes"] = numTimes;

            return View();
        }
    }
}